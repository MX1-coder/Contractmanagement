import 'package:flutter/material.dart';
import 'widgets/navbar.dart';
import 'package:home_page/utils/responsiveLayout.dart';
import 'widgets/SideButtons.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
          backgroundColor: Color(0xFFFAD6BE)
      ),
      home: const MyHomePage(),
    );
  }
}

class MyHomePage extends StatelessWidget {
  const MyHomePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return   Scaffold(
      body:Container(
        height: 1000,
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage('images/img_8.png'),
            fit: BoxFit.cover,
          ),
        ),

         // backgroundColor: Colors.black,

            child: SingleChildScrollView(
              child: Column(
                children: [
                  NavBar(),Body()
                ],
              ),
            ),



      ),
    );
  }
}

class Body extends StatelessWidget {
  const Body({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ResponsiveLayout(
        largeScreen: LargeChild(),
        mediumScreen: MediumChild(),
       smallScreen: SmallChild(),
    );
  }
}

class LargeChild extends StatelessWidget {
  const LargeChild({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Stack(
          children: [Container(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Image.asset(
                  'images/img.png',
                  width: 315,
                  height: 540,
                ),
                Image.asset(
                  'images/img_1.png',
                  width: 350,
                  height: 540,
                ),
                SizedBox(
                  width: 5,
                ),
                Image.asset(
                  'images/img_2.png',
                  width: 350,
                  height: 540,
                ),
                SizedBox(
                  width: 5,
                ),
                Image.asset(
                  'images/img_3.png',
                  width: 331,
                  height: 540,
                ),
              ],
            ),
          ),
            widget2(),
          ],
        ),
        //widget3()
      ],
    );
  }
}


class MediumChild extends StatelessWidget {
  const MediumChild({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}


class SmallChild extends StatelessWidget {
  const SmallChild({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        children: [
          Stack(
            children: [Container(
              height: 500,
              width: double.infinity,
              child: ListView(
                //mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                scrollDirection: Axis.horizontal,
                children: [
                  Image.asset(
                    'images/img_2.png',
                    width: 315,
                    height: 540,
                  ),
                  Image.asset(
                    'images/img1.png',
                    width: 350,
                    height: 540,
                  ),
                  SizedBox(
                    width: 5,
                  ),
                  Image.asset(
                    'images/img_3.png',
                    width: 350,
                    height: 540,
                  ),
                  SizedBox(
                    width: 5,
                  ),
                  Image.asset(
                    'images/img_4.png',
                    width: 331,
                    height: 540,
                  ),
                ],
              ),

            ),
            ],
          ),
          widgets(),
          widgetWhy()
        ],
      ),
    );
  }
}



