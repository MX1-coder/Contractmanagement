import 'package:flutter/material.dart';
import 'package:home_page/SideButtons.dart';
import 'package:home_page/DropDownFiles.dart';

class TopBarContents extends StatefulWidget {

  TopBarContents();

  @override
  _TopBarContentsState createState() => _TopBarContentsState();
}

class _TopBarContentsState extends State<TopBarContents> {
  final List _isHovering = [
    false,
    false,
    false,
    false,
    false,
    false,
    false,
    false
  ];

  var condrp=['Why Contract','Contract Benifits','Cost'];
  var currentItemSelected='Why Contract';

  @override
  Widget build(BuildContext context) {
    var screenSize = MediaQuery.of(context).size;
    return Container(
      color: Color(0xFFFAD6BE),
      child: Padding(
        padding: EdgeInsets.only(top: 20),
        child:
        Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            //SizedBox(width: screenSize.width/4,),
            Container(
              width: 200,
              height: 200,
              decoration: BoxDecoration(
                  image: DecorationImage(
                    image: AssetImage('images/icon_img.png',),
                  )
              ),
            ),
            SizedBox(width: screenSize.width / 15),
            InkWell(
              onHover: (value) {
                setState(() {
                  value
                      ? _isHovering[0] = true
                      : _isHovering[0] = false;
                });
              },
              onTap: () {},
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'HOME',
                    style: TextStyle(
                        color: _isHovering[0]
                            ? Color(0xFFED7826)
                            : Colors.black,
                        //fontWeight: FontWeight.bold,
                        fontSize: 16,

                    ),
                  ),
                  SizedBox(height: 5),
                  Visibility(
                    maintainAnimation: true,
                    maintainState: true,
                    maintainSize: true,
                    visible: _isHovering[0],
                    child: Container(
                      height: 2,
                      width: 20,
                      color: Color(0xFF051441),
                    ),
                  )
                ],
              ),
            ),

            SizedBox(width: screenSize.width / 15),
            InkWell(
              onHover: (value) {
                setState(() {
                  value
                      ? _isHovering[1] = true
                      : _isHovering[1] = false;
                });
              },
              onTap: () {

              },
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  /*Text(
                    'CONTRACT',
                    style: TextStyle(
                      c
                      //fontWeight: FontWeight.bold,
                      fontSize: 16,

                    ),
                  ),*/
                  DropdownButtonExample(),

                 // SizedBox(height: 5),
                  Visibility(
                    maintainAnimation: true,
                    maintainState: true,
                    maintainSize: true,
                    visible: _isHovering[1],
                    child: Container(
                      height: 2,
                      width: 15,
                      color: Color(0xFF051441),
                    ),
                  )
                ],
              ),

            ),

            SizedBox(width: screenSize.width / 15),
            InkWell(
              onHover: (value) {
                setState(() {
                  value
                      ? _isHovering[2] = true
                      : _isHovering[2] = false;
                });
              },
              onTap: () {},
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'PRODUCT INFIO',
                    style: TextStyle(
                      color: _isHovering[2]
                          ? Color(0xFFED7826)
                          : Colors.black,
                     // fontWeight: FontWeight.bold,
                      fontSize: 16,

                    ),
                  ),
                  SizedBox(height: 5),
                  Visibility(
                    maintainAnimation: true,
                    maintainState: true,
                    maintainSize: true,
                    visible: _isHovering[2],
                    child: Container(
                      height: 2,
                      width: 20,
                      color: Color(0xFF051441),
                    ),
                  )
                ],
              ),
            ),

            SizedBox(width: screenSize.width / 15),
            InkWell(
              onHover: (value) {
                setState(() {
                  value
                      ? _isHovering[3] = true
                      : _isHovering[3] = false;
                });
              },
              onTap: () {},
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'DOWNLOADS',
                    style: TextStyle(
                      color: _isHovering[3]
                          ? Color(0xFFED7826)
                          : Colors.black,
                     // fontWeight: FontWeight.bold,
                      fontSize: 16,

                    ),
                  ),
                  SizedBox(height: 5),
                  Visibility(
                    maintainAnimation: true,
                    maintainState: true,
                    maintainSize: true,
                    visible: _isHovering[3],
                    child: Container(
                      height: 2,
                      width: 20,
                      color: Color(0xFF051441),
                    ),
                  )
                ],
              ),
            ),

            SizedBox(width: screenSize.width / 15),
            InkWell(
              onHover: (value) {
                setState(() {
                  value
                      ? _isHovering[4] = true
                      : _isHovering[4] = false;
                });
              },
              onTap: () {},
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'CONTACT',
                    style: TextStyle(
                      color: _isHovering[4]
                          ? Color(0xFFED7826)
                          : Colors.black,
                      //fontWeight: FontWeight.bold,
                      fontSize: 16,

                    ),
                  ),
                  SizedBox(height: 5),
                  Visibility(
                    maintainAnimation: true,
                    maintainState: true,
                    maintainSize: true,
                    visible: _isHovering[4],
                    child: Container(
                      height: 2,
                      width: 20,
                      color: Color(0xFF051441),
                    ),
                  )
                ],
              ),
            ),
            SizedBox(width: screenSize.width / 15),
         btn(context),
          ],
        ),

      ),

    );
    //);
  }
}
