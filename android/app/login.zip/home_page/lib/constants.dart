import 'package:flutter/material.dart';


const ktextstyle=TextStyle(
    fontFamily: 'Montserrat',
    fontSize: 16,
    fontWeight: FontWeight.bold

);